some sort of utilities. Like byte swapping not really defined in DICOM but useful
