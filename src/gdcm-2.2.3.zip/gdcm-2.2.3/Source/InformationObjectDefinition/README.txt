Part 3.3


Footnote:
http://www.devarticles.com/c/a/XML/An-Introduction-to-XML-Schemas/
http://www.xml.com/pub/a/2000/11/29/schemas/part1.html
http://xmlfr.org/w3c/TR/xmlschema-0/
http://xmlfr.org/documentations/tutoriels/001218-0001
http://xml.ascc.net/schematron/
http://xml.ascc.net/resource/schematron/schematron.html
http://209.85.129.104/search?q=cache:sTA73AQ9KKMJ:lists.xml.org/archives/xml-dev/200005/msg00741.html+xml+schema+condition&hl=fr&gl=fr&ct=clnk&cd=2&client=firefox-a
