/*
* TODO: Is this really usefull ?
* Dump the dict from a DICOM file. Usefull for the private dict
*/
