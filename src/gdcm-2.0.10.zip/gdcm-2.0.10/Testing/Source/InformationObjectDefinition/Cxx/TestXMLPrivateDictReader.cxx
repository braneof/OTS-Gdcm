/*=========================================================================

  Program: GDCM (Grassroots DICOM). A DICOM library
  Module:  $URL$

  Copyright (c) 2006-2008 Mathieu Malaterre
  All rights reserved.
  See Copyright.txt or http://gdcm.sourceforge.net/Copyright.html for details.

     This software is distributed WITHOUT ANY WARRANTY; without even
     the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR
     PURPOSE.  See the above copyright notice for more information.

=========================================================================*/
#include "gdcmXMLPrivateDictReader.h"

int TestXMLPrivateDictReader(int argc, char *argv[])
{
  if( argc < 2 )
    {
    return 1;
    }
  const char *filename = argv[1];
  gdcm::XMLPrivateDictReader tr;
  tr.SetFilename(filename);
  tr.Read();

  std::cout << tr.GetPrivateDict() << std::endl;
  //tr.GetPrivateDict().PrintXML();

  return 0;
}
